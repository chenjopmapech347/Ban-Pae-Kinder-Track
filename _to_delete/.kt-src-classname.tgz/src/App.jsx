import './index.css';
import { useState, useEffect, lazy, Suspense } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import VersionChecker from './components/VersionChecker';
import LoginPage from './pages/LoginPage';
import AdminDashboard from './pages/AdminDashboard';
import TeacherDashboard from './pages/TeacherDashboard';
import ParentView from './pages/ParentView';
import ReportPage from './pages/ReportPage';
const StudentReportTab = lazy(() => import('./components/admin/StudentReportTab'));
import EvaluationForm from './components/EvaluationForm';
import StudentModal from './components/StudentModal';
import ChangePasswordModal from './components/ChangePasswordModal';
import { version as APP_VERSION } from '../package.json';
import { ui, useViewport } from './ui/ui';

const APP_DEVELOPER = 'นายเจนจบ มาเพ็ชร์';

const ROLE_LABEL = {
  admin:   '🛡️ ผู้ดูแลระบบ',
  teacher: '👨‍🏫 คุณครู',
  parent:  '👨‍👩‍👧 ผู้ปกครอง',
};

const ROLE_AVATAR = {
  admin:   'AD',
  teacher: 'TR',
  parent:  'PR',
};

function AppShell() {
  useViewport(); // re-render เมื่อหน้าจอข้ามจุดตัด media query (ใช้กับ ui())
  const {
    role, user, logout,
    academicYears, academicYear, setAcademicYear,
    currentTerm, setCurrentTerm,
    evaluatingStudent, setEvaluatingStudent,
    selectedStudent, setSelectedStudent,
    isAdding, setIsAdding,
    handleSaveEvaluation, assessmentTopics, addStudent,
    autoSyncStatus, autoSyncError, lastSyncFailed, snapshotSizeKB,
    pullSyncStatus, isFirebaseConfigured,
    syncPushToFirebase, syncPullFromFirebase,
    schools, schoolLogo,
  } = useApp();

  const [manualSaveStatus, setManualSaveStatus] = useState('idle');   // idle | saving | done | error
  const [manualPullStatus, setManualPullStatus] = useState('idle');   // idle | pulling | done | error

  const handleManualSave = async () => {
    if (manualSaveStatus === 'saving') return;
    setManualSaveStatus('saving');
    try {
      const result = await syncPushToFirebase();
      setManualSaveStatus(result?.ok ? 'done' : 'error');
    } catch { setManualSaveStatus('error'); }
    setTimeout(() => setManualSaveStatus('idle'), 3000);
  };

  const handleManualRefresh = async () => {
    if (manualPullStatus === 'pulling') return;
    setManualPullStatus('pulling');
    try {
      const result = await syncPullFromFirebase();
      setManualPullStatus(result?.ok ? 'done' : 'error');
    } catch { setManualPullStatus('error'); }
    setTimeout(() => setManualPullStatus('idle'), 3000);
  };

  const schoolName = schools?.[0]?.name ?? 'KinderTrack';

  /* ── Dynamic favicon: ใช้โลโก้โรงเรียนแทน vite.svg ── */
  useEffect(() => {
    let link = document.querySelector("link[rel='icon']");
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    if (schoolLogo) {
      link.href = schoolLogo;
      link.type = 'image/png';
    } else {
      link.href = '/logo.png';
      link.type = 'image/png';
    }
  }, [schoolLogo]);

  const [changePwOpen, setChangePwOpen] = useState(false);

  // แจ้งเตือนเมื่อ localStorage เต็ม (quota exceeded)
  const [lsQuotaWarning, setLsQuotaWarning] = useState(false);
  useEffect(() => {
    const handler = () => {
      setLsQuotaWarning(true);
      setTimeout(() => setLsQuotaWarning(false), 8000);
    };
    window.addEventListener('ls-quota-error', handler);
    return () => window.removeEventListener('ls-quota-error', handler);
  }, []);

  if (!role) return <LoginPage />;

  return (
    <div {...ui('container')}>
      {/* ── App Header ── */}
      <header {...ui('app-header no-print')}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '.85rem' }}>
          <img
            src="/logo.png"
            alt={`โลโก้ ${schoolName}`}
            style={{ width: '52px', height: '52px', borderRadius: '50%', objectFit: 'cover',
                     border: '2px solid rgba(255,255,255,0.4)', flexShrink: 0 }}
            onError={e => { e.target.style.display = 'none'; }}
          />
          <div style={{ lineHeight: 1.3 }}>
            <div style={{ fontWeight: 800, fontSize: '1rem', color: 'white' }}>
              ระบบบันทึกพัฒนาการเด็กปฐมวัย
            </div>
            <div style={{ fontSize: '.75rem', color: 'rgba(255,255,255,0.85)', fontWeight: 600 }}>
              {schoolName} · KinderTrack
            </div>
            <div {...ui('subtitle', { fontSize: '.7rem', opacity: .75 })}>
              {ROLE_LABEL[role] ?? role}
            </div>
          </div>
        </div>

        <div {...ui('flex items-center gap-2', { flexWrap: 'wrap' })}>
          <select value={academicYear} onChange={(e) => setAcademicYear(e.target.value)}>
            {academicYears.map((y) => (
              <option key={y} value={y}>ปีการศึกษา {y}</option>
            ))}
          </select>

          <select value={currentTerm} onChange={(e) => setCurrentTerm(e.target.value)}>
            <option value="1">ภาคเรียนที่ 1</option>
            <option value="2">ภาคเรียนที่ 2</option>
          </select>

          {/* ── Firebase sync status indicators ── */}
          {isFirebaseConfigured && pullSyncStatus === 'pulling' && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: '.35rem',
              background: 'rgba(255,255,255,0.15)', borderRadius: '999px',
              padding: '.2rem .7rem', fontSize: '.72rem', fontWeight: 700,
              color: 'white', border: '1.5px solid rgba(255,255,255,0.3)',
            }}>
              <span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>🔄</span> กำลังโหลดข้อมูล…
            </div>
          )}
          {isFirebaseConfigured && pullSyncStatus === 'error' && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: '.35rem',
              background: 'rgba(255,80,80,0.25)', borderRadius: '999px',
              padding: '.2rem .7rem', fontSize: '.72rem', fontWeight: 700,
              color: 'white', border: '1.5px solid rgba(255,80,80,0.4)',
            }}>
              ⚠️ โหลดข้อมูลไม่สำเร็จ
            </div>
          )}
          {autoSyncStatus !== 'idle' && pullSyncStatus !== 'pulling' && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: '.35rem',
              background: autoSyncStatus === 'done' && !isFirebaseConfigured
                ? 'rgba(251,191,36,0.25)'
                : autoSyncStatus === 'error'
                  ? 'rgba(255,80,80,0.25)'
                  : 'rgba(255,255,255,0.15)',
              borderRadius: '999px',
              padding: '.2rem .7rem', fontSize: '.72rem', fontWeight: 700,
              color: 'white',
              border: autoSyncStatus === 'done' && !isFirebaseConfigured
                ? '1.5px solid rgba(251,191,36,0.5)'
                : '1.5px solid rgba(255,255,255,0.3)',
              transition: 'all .3s',
            }}>
              {autoSyncStatus === 'pending'  && <><span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>⏳</span> รอบันทึก…</>}
              {autoSyncStatus === 'syncing'  && <><span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>🔄</span> {isFirebaseConfigured ? 'กำลังบันทึกลงฐานข้อมูล…' : 'กำลังบันทึก…'}</>}
              {autoSyncStatus === 'done'     && isFirebaseConfigured  && <>✅ บันทึกลงฐานข้อมูลแล้ว</>}
              {autoSyncStatus === 'done'     && !isFirebaseConfigured && <>💾 บันทึกเฉพาะในเครื่องนี้</>}
              {autoSyncStatus === 'error'    && (
                <span title={autoSyncError || 'sync failed'}>
                  ❌ บันทึกไม่สำเร็จ {autoSyncError && <span style={{ fontWeight: 400, opacity: 0.8 }}>— {autoSyncError.slice(0, 60)}{autoSyncError.length > 60 ? '…' : ''}</span>}
                </span>
              )}
            </div>
          )}

          {/* ── ปุ่ม บันทึก (manual save) ── */}
          {isFirebaseConfigured && (
            <button type="button"
              onClick={handleManualSave}
              disabled={manualSaveStatus === 'saving' || autoSyncStatus === 'syncing'}
              style={{
                display: 'flex', alignItems: 'center', gap: '.35rem',
                background: manualSaveStatus === 'done'  ? 'rgba(34,197,94,0.35)'
                          : manualSaveStatus === 'error' ? 'rgba(239,68,68,0.35)'
                          : 'rgba(255,255,255,0.2)',
                color: 'white',
                border: manualSaveStatus === 'done'  ? '1.5px solid rgba(34,197,94,0.6)'
                      : manualSaveStatus === 'error' ? '1.5px solid rgba(239,68,68,0.6)'
                      : '1.5px solid rgba(255,255,255,0.4)',
                borderRadius: '999px', padding: '.35rem .85rem',
                fontSize: '.8rem', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
                transition: 'all .2s', minWidth: '80px', justifyContent: 'center',
                opacity: manualSaveStatus === 'saving' ? 0.7 : 1,
              }}>
              <span style={manualSaveStatus === 'saving' ? { animation: 'spin 1s linear infinite', display: 'inline-block' } : {}}>
                {manualSaveStatus === 'done' ? '✅' : manualSaveStatus === 'error' ? '❌' : manualSaveStatus === 'saving' ? '🔄' : '💾'}
              </span>
              {manualSaveStatus === 'done' ? 'บันทึกแล้ว' : manualSaveStatus === 'error' ? 'ล้มเหลว' : manualSaveStatus === 'saving' ? 'กำลังบันทึก…' : 'บันทึก'}
            </button>
          )}

          {/* ── ปุ่ม รีเฟรช (manual pull) ── */}
          {isFirebaseConfigured && (
            <button type="button"
              onClick={handleManualRefresh}
              disabled={manualPullStatus === 'pulling' || pullSyncStatus === 'pulling'}
              style={{
                display: 'flex', alignItems: 'center', gap: '.35rem',
                background: manualPullStatus === 'done'  ? 'rgba(34,197,94,0.35)'
                          : manualPullStatus === 'error' ? 'rgba(239,68,68,0.35)'
                          : 'rgba(255,255,255,0.15)',
                color: 'white',
                border: manualPullStatus === 'done'  ? '1.5px solid rgba(34,197,94,0.6)'
                      : manualPullStatus === 'error' ? '1.5px solid rgba(239,68,68,0.6)'
                      : '1.5px solid rgba(255,255,255,0.3)',
                borderRadius: '999px', padding: '.35rem .85rem',
                fontSize: '.8rem', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
                transition: 'all .2s', minWidth: '90px', justifyContent: 'center',
                opacity: manualPullStatus === 'pulling' ? 0.7 : 1,
              }}>
              <span style={(manualPullStatus === 'pulling' || pullSyncStatus === 'pulling') ? { animation: 'spin 1s linear infinite', display: 'inline-block' } : {}}>
                {manualPullStatus === 'done' ? '✅' : manualPullStatus === 'error' ? '❌' : '🔄'}
              </span>
              {manualPullStatus === 'done' ? 'อัปเดตแล้ว' : manualPullStatus === 'error' ? 'ล้มเหลว' : (manualPullStatus === 'pulling' || pullSyncStatus === 'pulling') ? 'กำลังโหลด…' : 'รีเฟรช'}
            </button>
          )}


          <div {...ui('flex items-center gap-2')}>
            <div {...ui('user-avatar')}>{ROLE_AVATAR[role] ?? '?'}</div>
            <div style={{ lineHeight: 1.4 }}>
              <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'white' }}>{user?.name}</div>
              <div style={{ display: 'flex', gap: '.35rem', marginTop: '.15rem', flexWrap: 'wrap' }}>
                {/* เปลี่ยนรหัสผ่าน — เฉพาะ admin และ ครู */}
                {(role === 'admin' || role === 'teacher') && (
                  <button type="button"
                    onClick={() => setChangePwOpen(true)}
                    style={{
                      fontSize: '.68rem', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
                      background: 'rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.85)',
                      border: '1.5px solid rgba(255,255,255,0.3)',
                      borderRadius: '999px', padding: '.15rem .6rem',
                      transition: 'all .15s',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.22)'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.12)'; }}>
                    🔑 เปลี่ยนรหัสผ่าน
                  </button>
                )}
                <button type="button"
                  onClick={logout}
                  style={{
                    fontSize: '.68rem', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
                    background: 'rgba(255,255,255,0.18)', color: 'white',
                    border: '1.5px solid rgba(255,255,255,0.4)',
                    borderRadius: '999px', padding: '.15rem .65rem',
                    transition: 'background .15s',
                  }}>
                  🚪 ออกจากระบบ
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* ── แบนเนอร์เตือนถาวร: บันทึกลงระบบไม่สำเร็จ ── */}
      {isFirebaseConfigured && lastSyncFailed && (
        <div style={{
          background: '#fef2f2', borderBottom: '2px solid #fca5a5',
          padding: '.55rem 1.2rem', display: 'flex', alignItems: 'center',
          gap: '.6rem', fontSize: '.8rem', fontWeight: 700, color: '#991b1b',
          zIndex: 100,
        }}>
          <span style={{ fontSize: '1.1rem' }}>⚠️</span>
          <span>
            <strong>ข้อมูลในเครื่องนี้อาจยังไม่ถูกบันทึกลงระบบ Cloud</strong>
            {snapshotSizeKB > 0 && ` (ขนาด ${snapshotSizeKB} KB)`}
            {' '}— กรุณากด <strong>บันทึก↑</strong> ในแถบด้านบน หรือติดต่อผู้ดูแลระบบ
          </span>
          <span style={{ marginLeft: 'auto', fontSize: '.72rem', fontWeight: 400, opacity: .7 }}>
            {autoSyncError || 'ข้อมูลบันทึกเฉพาะในเครื่องนี้ ถ้าเปลี่ยน browser หรือเครื่อง ข้อมูลอาจหาย'}
          </span>
        </div>
      )}

      <main>
        {evaluatingStudent ? (
          <EvaluationForm student={evaluatingStudent} onSave={handleSaveEvaluation}
            onCancel={() => setEvaluatingStudent(null)} assessmentTopics={assessmentTopics} />
        ) : selectedStudent && role === 'parent' ? (
          <div {...ui('animate-fade')}>
            <div {...ui('page-header mb-5 no-print')}>
              <button type="button" {...ui('btn')} onClick={() => setSelectedStudent(null)}>← ย้อนกลับ</button>
            </div>
            <Suspense fallback={<div style={{ padding: '2rem', textAlign: 'center', color: '#6b7280' }}>กำลังโหลด...</div>}>
              <StudentReportTab initialStudentId={selectedStudent.id} />
            </Suspense>
          </div>
        ) : selectedStudent ? (
          <ReportPage />
        ) : role === 'admin' ? (
          <AdminDashboard />
        ) : role === 'teacher' ? (
          <TeacherDashboard />
        ) : (
          <ParentView />
        )}
      </main>

      <StudentModal key="add-student" isOpen={isAdding} onClose={() => setIsAdding(false)} onSave={addStudent} />
      <ChangePasswordModal isOpen={changePwOpen} onClose={() => setChangePwOpen(false)} />

      {/* ── localStorage quota warning toast ── */}
      {lsQuotaWarning && (
        <div style={{
          position: 'fixed', bottom: '1.2rem', left: '50%', transform: 'translateX(-50%)',
          background: '#dc2626', color: 'white', borderRadius: '12px',
          padding: '.65rem 1.2rem', fontWeight: 700, fontSize: '.82rem',
          boxShadow: '0 4px 24px rgba(0,0,0,0.25)', zIndex: 9999,
          display: 'flex', alignItems: 'center', gap: '.5rem',
        }}>
          ⚠️ พื้นที่เก็บข้อมูลในเครื่องเต็ม — ข้อมูลบางส่วนอาจไม่ได้บันทึก กรุณาแจ้งผู้ดูแลระบบ
        </div>
      )}

      {/* ── Footer ── */}
      <footer {...ui('no-print', {
        textAlign: 'center', padding: '.75rem 1rem',
        fontSize: '.7rem', color: 'rgba(255,255,255,0.6)',
        background: 'linear-gradient(135deg,#5b21b6,#6d28d9)',
        borderTop: '1px solid rgba(255,255,255,0.12)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        gap: '.75rem', flexWrap: 'wrap',
      })}>
        <span>💻 KinderTrack v{APP_VERSION}</span>
        <span style={{ opacity: .35 }}>|</span>
        <span>{schoolName}</span>
        <span style={{ opacity: .35 }}>|</span>
        <span>พัฒนาโดย {APP_DEVELOPER}</span>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <VersionChecker />
      <AppShell />
    </AppProvider>
  );
}
