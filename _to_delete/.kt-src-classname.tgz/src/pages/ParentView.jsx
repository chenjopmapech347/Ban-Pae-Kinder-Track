import { useState, useMemo, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { ui } from '../ui/ui';

export default function ParentView() {
  const { user, students, setSelectedStudent,
    teachers, announcements,
    dailyRecords, syncPullFromFirebase, isFirebaseConfigured,
  } = useApp();

  const [refreshing, setRefreshing] = useState(false);
  const handleRefresh = useCallback(async () => {
    if (!isFirebaseConfigured) return;
    setRefreshing(true);
    try { await syncPullFromFirebase(); } finally { setRefreshing(false); }
  }, [syncPullFromFirebase, isFirebaseConfigured]);

  // โหลดข้อมูลใหม่อัตโนมัติทุก 60 วินาที (ครูอาจบันทึกข้อมูลหลังผู้ปกครอง login)
  useEffect(() => {
    if (!isFirebaseConfigured) return;
    const timer = setInterval(handleRefresh, 60_000);
    return () => clearInterval(timer);
  }, [handleRefresh, isFirebaseConfigured]);

  const student = students.find(s => s.id === user?.studentId);
  const classTeacher = teachers?.find(t => t.className === student?.className);

  // ประกาศที่ผู้ปกครองเห็น: ทุกคน + ห้องบุตรหลาน
  const parentAnnouncements = (announcements ?? [])
    .filter(a => !a.target || a.target === 'all' || a.target === student?.className)
    .slice(0, 1);

  // นับสถิติจาก dailyRecords (ที่ครูบันทึก) — ตรงกับข้อมูลจริงใน AttendanceTab
  const { total, present, absent } = useMemo(() => {
    let p = 0, ab = 0;
    Object.values(dailyRecords ?? {}).forEach(day => {
      const rec = day[String(student?.id)];
      if (!rec?.attendance) return;
      if (rec.attendance === 'มา') p++;
      else ab++;
    });
    return { total: p + ab, present: p, absent: ab };
  }, [dailyRecords, student?.id]);

  if (!student) {
    return (
      <div {...ui('glass p-8 text-center')}>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>😅</div>
        <p>ไม่พบข้อมูลนักเรียนที่เชื่อมกับบัญชีผู้ปกครอง</p>
      </div>
    );
  }

  const isBoy = student.name.includes('ชาย');

  const pct = total ? Math.round((present / total) * 100) : 0;


  return (
    <div {...ui('animate-fade', { maxWidth: 600, margin: '0 auto' })}>
      {/* Welcome Header */}
      <div
        {...ui('glass mb-6', {
          background: 'linear-gradient(135deg, #7c3aed 0%, #a855f7 50%, #ec4899 100%)',
          color: 'white',
          padding: '2rem',
        })}
      >
        <div {...ui('flex items-center gap-4', { flexWrap: 'wrap' })}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%',
            background: 'rgba(255,255,255,0.25)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '2rem', flexShrink: 0,
            border: '3px solid rgba(255,255,255,0.5)',
          }}>
            {student.photo
              ? <img src={student.photo} alt={student.name} style={{ width:'100%', height:'100%', objectFit:'cover', borderRadius:'50%' }} />
              : (isBoy ? '👦' : '👧')}
          </div>
          <div>
            {student.guardianName ? (
              <h2 style={{ color: 'white', fontSize: '1.4rem', marginBottom: '0.25rem' }}>
                สวัสดีคุณ {student.guardianName} 😊
              </h2>
            ) : (
              <h2 style={{ color: 'white', fontSize: '1.4rem', marginBottom: '0.25rem' }}>
                สวัสดีคุณผู้ปกครอง 😊
              </h2>
            )}
            <div style={{ opacity: 0.9, fontSize: '1rem', fontWeight: 600 }}>{student.name}</div>
            <div style={{ opacity: 0.75, fontSize: '0.82rem', marginTop: '0.2rem' }}>
              ชั้นอนุบาล {student.level?.replace('K', '')} · อายุ {student.age} ปี
            </div>
            {student.guardianOcc && (
              <div style={{ opacity: 0.7, fontSize: '0.75rem', marginTop: '0.1rem' }}>
                อาชีพ: {student.guardianOcc}
              </div>
            )}
          </div>
        </div>

        {/* ปุ่ม Refresh — โหลดข้อมูลล่าสุดจากครู */}
        {isFirebaseConfigured && (
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            title="โหลดข้อมูลล่าสุดจากครู"
            style={{
              marginLeft: 'auto', marginTop: '.25rem', alignSelf: 'flex-start',
              background: 'rgba(255,255,255,0.2)', color: 'white',
              border: '1.5px solid rgba(255,255,255,0.4)',
              borderRadius: '999px', padding: '.3rem .8rem',
              fontWeight: 700, fontSize: '.75rem', cursor: refreshing ? 'not-allowed' : 'pointer',
              display: 'flex', alignItems: 'center', gap: '.35rem',
              opacity: refreshing ? 0.65 : 1, fontFamily: 'inherit',
            }}
          >
            <span style={refreshing ? { animation: 'spin 1s linear infinite', display: 'inline-block' } : {}}>
              🔄
            </span>
            {refreshing ? 'กำลังโหลด…' : 'รีเฟรช'}
          </button>
        )}
      </div>


      {/* Announcements */}
      {parentAnnouncements.length > 0 && (
        <div style={{ display:'flex', flexDirection:'column', gap:'.5rem', marginBottom:'1.25rem' }}>
          {parentAnnouncements.map((a, idx) => (
            <div key={a.id} {...ui('announce-banner')}>
              <span {...ui('announce-icon')}>📢</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', gap:'.35rem', alignItems:'center', flexWrap:'wrap', marginBottom:'.12rem' }}>
                  {idx === 0 && <span style={{ background:'#7c3aed', color:'white', fontSize:'.63rem', fontWeight:800, padding:'1px 6px', borderRadius:'999px' }}>ล่าสุด</span>}
                  {(!a.target || a.target === 'all') ? (
                    <span style={{ background:'#dbeafe', color:'#1e40af', fontSize:'.65rem', fontWeight:700, padding:'1px 7px', borderRadius:'999px' }}>ทุกคน</span>
                  ) : (
                    <span style={{ background:'#ede9fe', color:'#7c3aed', fontSize:'.65rem', fontWeight:700, padding:'1px 7px', borderRadius:'999px' }}>ห้อง {a.target}</span>
                  )}
                </div>
                <div {...ui('announce-title')}>{a.title}</div>
                {a.body && <div style={{ fontSize:'.78rem', color:'#4b5563', marginTop:'.1rem' }}>{a.body}</div>}
                <div {...ui('announce-date')}>📅 {a.date}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Teacher Info */}
      {classTeacher && (
        <div {...ui('glass-card mb-6')}>
          <h3 {...ui('mb-3')}>👩‍🏫 ครูประจำชั้น</h3>
          <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
            <div style={{
              width:52, height:52, borderRadius:'50%',
              background:'linear-gradient(135deg,#7c3aed,#a855f7)',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:'1.6rem', flexShrink:0,
            }}>👩‍🏫</div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:800, fontSize:'1rem' }}>
                {classTeacher.firstName && classTeacher.lastName
                  ? `${classTeacher.firstName} ${classTeacher.lastName}`
                  : classTeacher.name}
              </div>
              <div style={{ fontSize:'.82rem', color:'#6b7280', marginTop:'.2rem' }}>
                ห้อง {classTeacher.className}
              </div>
            </div>
            {classTeacher.phone && (
              <a href={`tel:${classTeacher.phone}`} style={{
                display:'flex', flexDirection:'column', alignItems:'center', gap:'.2rem',
                background:'#d1fae5', color:'#065f46', borderRadius:'12px',
                padding:'.6rem .9rem', textDecoration:'none', fontWeight:700, fontSize:'.82rem',
              }}>
                📞 <span>{classTeacher.phone}</span>
              </a>
            )}
          </div>
        </div>
      )}

      {/* Attendance */}
      <div {...ui('glass-card mb-6')}>
        <h3 {...ui('mb-4')}>📅 สถิติการมาเรียน</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '0.75rem', marginBottom: '1rem' }}>
          <div style={{ textAlign: 'center', background: '#d1fae5', borderRadius: '14px', padding: '1rem' }}>
            <div style={{ fontSize: '1.75rem', fontWeight: 900, color: '#065f46' }}>{present}</div>
            <div style={{ fontSize: '0.78rem', color: '#065f46', fontWeight: 600 }}>✅ มาเรียน</div>
          </div>
          <div style={{ textAlign: 'center', background: '#fee2e2', borderRadius: '14px', padding: '1rem' }}>
            <div style={{ fontSize: '1.75rem', fontWeight: 900, color: '#991b1b' }}>{absent}</div>
            <div style={{ fontSize: '0.78rem', color: '#991b1b', fontWeight: 600 }}>❌ ขาด/ลา</div>
          </div>
          <div style={{ textAlign: 'center', background: '#ede9fe', borderRadius: '14px', padding: '1rem' }}>
            <div style={{ fontSize: '1.75rem', fontWeight: 900, color: '#7c3aed' }}>{pct}%</div>
            <div style={{ fontSize: '0.78rem', color: '#7c3aed', fontWeight: 600 }}>📊 อัตรามา</div>
          </div>
        </div>
        <div {...ui('progress-bar')}>
          <div
            {...ui('progress-fill', {
              width: pct + '%',
              background: pct >= 80
                ? 'linear-gradient(90deg,#10b981,#34d399)'
                : pct >= 60
                  ? 'linear-gradient(90deg,#f59e0b,#fbbf24)'
                  : 'linear-gradient(90deg,#ef4444,#fb7185)',
            })}
          />
        </div>
        <div {...ui('text-xs text-muted mt-2 text-right')}>{present} จาก {total} วัน</div>
      </div>



      {/* Physical Info */}
      <div {...ui('glass-card mb-6')}>
        <h3 {...ui('mb-3')}>📏 ข้อมูลร่างกาย</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          <div style={{ background: '#dbeafe', borderRadius: '12px', padding: '0.75rem', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', fontWeight: 900, color: '#1e40af' }}>{student.weight ?? '—'}</div>
            <div style={{ fontSize: '0.78rem', color: '#1e40af', fontWeight: 600 }}>⚖️ น้ำหนัก (กก.)</div>
          </div>
          <div style={{ background: '#fce7f3', borderRadius: '12px', padding: '0.75rem', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', fontWeight: 900, color: '#9d174d' }}>{student.height ?? '—'}</div>
            <div style={{ fontSize: '0.78rem', color: '#9d174d', fontWeight: 600 }}>📐 ส่วนสูง (ซม.)</div>
          </div>
        </div>
      </div>


      {/* CTA */}
      <button
        type="button"
        {...ui('btn btn-primary w-full', { padding: '1rem', fontSize: '1rem', borderRadius: '16px' })}
        onClick={() => setSelectedStudent(student)}
      >
        📖 ดูสมุดรายงานประจำตัวฉบับเต็ม
      </button>
    </div>
  );
}
