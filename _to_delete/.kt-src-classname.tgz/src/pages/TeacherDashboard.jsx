import { useState, useMemo, useEffect, useRef, lazy, Suspense } from 'react';
import { useApp } from '../context/AppContext';
import { todayISO, formatDateThai, isStudentActive } from '../utils/helpers';
import { getDayRecord, hasHygieneToday } from '../utils/attendance';
import StudentModal from '../components/StudentModal';
import DashboardSidebar from '../components/ui/DashboardSidebar';
import ErrorBoundary from '../components/ui/ErrorBoundary';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../lib/firebase';
import { ui } from '../ui/ui';

const EvaluationTab          = lazy(() => import('../components/admin/EvaluationTab'));
const AbilityAssessmentTab   = lazy(() => import('../components/admin/AbilityAssessmentTab'));
const ReportsTab             = lazy(() => import('../components/admin/ReportsTab'));
const MediaTab               = lazy(() => import('../components/admin/MediaTab'));
const MediaBorrowTab         = lazy(() => import('../components/admin/MediaBorrowTab'));
const CornerTab              = lazy(() => import('../components/admin/CornerTab'));
const InnerCornerTab         = lazy(() => import('../components/admin/InnerCornerTab'));
const DevelopmentalReportTab = lazy(() => import('../components/admin/DevelopmentalReportTab'));
const HealthCheckTab         = lazy(() => import('../components/admin/HealthCheckTab'));
const IllnessCheckTab        = lazy(() => import('../components/admin/IllnessCheckTab'));
const ToothBrushTab          = lazy(() => import('../components/admin/ToothBrushTab'));
const LunchTab               = lazy(() => import('../components/admin/LunchTab'));
const MilkTab                = lazy(() => import('../components/admin/MilkTab'));
const NutritionTab           = lazy(() => import('../components/admin/NutritionTab'));
const DailyRoutineTab        = lazy(() => import('../components/admin/DailyRoutineTab'));
const SpecialEventTab        = lazy(() => import('../components/admin/SpecialEventTab'));
const StudentReportTab       = lazy(() => import('../components/admin/StudentReportTab'));
const TeacherOverviewTab     = lazy(() => import('../components/teacher/TeacherOverviewTab'));
const AdminAttTab            = lazy(() => import('../components/admin/AttendanceTab'));
const PickupTab              = lazy(() => import('../components/admin/PickupTab'));
const ActivityLogTab         = lazy(() => import('../components/admin/ActivityLogTab'));
const QaStandardView         = lazy(() => import('../components/QaStandardView'));
const Std2SelfTab            = lazy(() => import('../components/teacher/Std2SelfTab'));
const NationalStandardsTab   = lazy(() => import('../components/admin/NationalStandardsTab'));
const IndicatorsTab          = lazy(() => import('../components/admin/IndicatorsTab'));
const AIChatTab              = lazy(() => import('../components/AIChatTab'));
const HelpTab                = lazy(() => import('../components/admin/HelpTab'));

/* ── Menu definition ───────────────────────────────────────────────────────── */
const TEACHER_TAB_GROUPS = [
  {
    label: 'หน้าหลัก',
    color: '#7c3aed',
    tabs: [
      { id: 'main',            label: '🏠 หน้าหลัก'      },
      { id: 'students',        label: '👨‍🎓 นักเรียน'      },
      { id: 'pins',            label: '🔑 PIN ผู้ปกครอง' },
      { id: 'teacherannounce', label: '📢 ประกาศ'         },
      { id: 'aichat',          label: '🤖 AI ผู้ช่วย'    },
    ],
  },
  {
    label: 'บันทึกประจำวัน',
    color: '#0891b2',
    tabs: [
      { id: 'overview',     label: '📊 ภาพรวมวันนี้'    },  // ดูสถานะก่อนเริ่มวัน
      { id: 'attendance',   label: '✅ การมาเรียน'       },  // เช้า — เช็คชื่อ
      { id: 'healthcheck',  label: '🏥 ตรวจสุขภาพ'       },  // เช้า — ตรวจสุขภาพ
      { id: 'illnesscheck', label: '🤒 คัดกรองอาการป่วย' },  // เช้า — คัดกรอง
      { id: 'milk',         label: '🥛 ดื่มนม'           },  // เช้า — นมเช้า
      { id: 'dailyroutine', label: '🗓️ กิจกรรมประจำวัน'  },  // ระหว่างวัน
      { id: 'lunch',        label: '🍱 อาหารกลางวัน'     },  // กลางวัน
      { id: 'toothbrush',   label: '🪥 แปรงฟัน'          },  // หลังอาหาร
      // { id: 'pickup',       label: '🚗 รับกลับบ้าน'     },  // บ่าย — รับกลับ (ซ่อนชั่วคราว)
    ],
  },
  {
    label: 'บันทึกประจำสัปดาห์',
    color: '#059669',
    tabs: [
      { id: 'innercorner', label: '🏡 มุมประสบการณ์ในห้อง'  },  // ในห้องก่อน
      { id: 'corner',      label: '🌿 แหล่งเรียนรู้นอกห้อง' },  // แล้วนอกห้อง
    ],
  },
  {
    label: 'บันทึกตามโอกาส',
    color: '#7c3aed',
    tabs: [
      { id: 'healthcheck',  label: '🏥 ตรวจสุขภาพ'       },  // ตรวจสุขภาพตามโอกาส
      { id: 'nutrition',    label: '⚖️ ภาวะโภชนาการ'   },  // ประเมินสุขภาพ
      { id: 'specialevent', label: '🎉 กิจกรรมวันสำคัญ' },  // กิจกรรมพิเศษ
    ],
  },
  {
    label: 'รายงานและประเมินผล',
    color: '#4f46e5',
    tabs: [
      { id: 'evaluation',    label: '✏️ ประเมินพัฒนาการ'  },  // 1. ลงมือประเมิน
      { id: 'abilityassess', label: '🎯 ประเมินความสามารถผู้เรียน' },  // 2. หลักสูตร 2560
      { id: 'activitylog',   label: '📜 ประวัติการประเมิน' },  // 2. ดูประวัติ
      { id: 'devreport',     label: '📑 ผลการประเมินพัฒนาการ' },  // 3. ผลการประเมินพัฒนาการ
      { id: 'formreports',   label: '📄 รายงานสรุป'       },  // 4. รายงานสรุป
      { id: 'studentreport', label: '📒 สมุดรายงาน อ.01' },  // 5. ผลลัพธ์สุดท้าย
    ],
  },
  {
    label: 'สื่อและสภาพแวดล้อม',
    color: '#d97706',
    tabs: [
      { id: 'media',       label: '📚 ทะเบียนผลิตสื่อ'  },  // ขึ้นทะเบียนก่อน
      { id: 'mediaborrow', label: '🔄 รายการยืม-คืนสื่อ' },  // แล้วจึงยืม-คืน
    ],
  },
  {
    label: 'มาตรฐานและโปรไฟล์',
    color: '#6b7280',
    tabs: [
      { id: 'profile',     label: '👤 โปรไฟล์ของฉัน'     },  // ข้อมูลส่วนตัว
      { id: 'std2self',    label: '👩‍🏫 มาตรฐานที่ 2'      },  // มาตรฐานครู
      { id: 'standards',   label: '🗺️ มาตรฐานปฐมวัย'     },  // มาตรฐานเด็ก
      { id: 'nationalstd', label: '🏛 มาตรฐานแห่งชาติ'   },  // ระดับชาติ
      { id: 'indicators',  label: '🔬 ตัวบ่งชี้'          },  // ดูเท่านั้น
    ],
  },
  {
    label: 'ช่วยเหลือ',
    color: '#7c3aed',
    tabs: [
      { id: 'help', label: '📖 คู่มือการใช้งาน' },
    ],
  },
];

/* ── Constants ─────────────────────────────────────────────────────────────── */
const ATT_OPTS   = ['มา', 'ขาด', 'ลา', 'ป่วย'];
const LUNCH_OPTS = ['หมด', 'เกือบหมด', 'ครึ่งเดียว', 'ไม่ทาน'];
const ATT_COLOR  = {
  มา:   { bg: '#d1fae5', color: '#065f46' },
  ขาด:  { bg: '#fee2e2', color: '#991b1b' },
  ลา:   { bg: '#fef3c7', color: '#92400e' },
  ป่วย: { bg: '#dbeafe', color: '#1e40af' },
};

/* ── Sub-components (must be outside TeacherDashboard to avoid re-mount) ──── */
function StudentPinRow({ student, onSave }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal]         = useState(student.parentPin ?? '');
  const [show, setShow]       = useState(false);
  if (!editing) return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.5rem .75rem',
      background: '#f9fafb', borderRadius: '8px', border: '1px solid #e5e7eb' }}>
      <span style={{ flex: 1, fontWeight: 600, fontSize: '.9rem' }}>{student.name}</span>
      <span style={{ fontSize: '.8rem', color: '#6b7280' }}>PIN:</span>
      <code style={{ background: '#ede9fe', padding: '.15rem .5rem', borderRadius: '5px', fontSize: '.82rem', letterSpacing: show ? '0' : '.15em' }}>
        {show ? (student.parentPin ?? '—') : '••••'}
      </code>
      <button type="button" onClick={() => setShow(s => !s)}
        style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '.8rem', padding: 0 }}>
        {show ? '🙈' : '👁️'}
      </button>
      <button type="button" {...ui('btn btn-sm')}
        onClick={() => { setVal(student.parentPin ?? ''); setEditing(true); }}>
        ✏️ แก้ไข
      </button>
    </div>
  );
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.5rem .75rem',
      background: '#faf5ff', borderRadius: '8px', border: '2px solid #a78bfa' }}>
      <span style={{ flex: 1, fontWeight: 600, fontSize: '.9rem' }}>{student.name}</span>
      <span style={{ fontSize: '.8rem', color: '#6b7280' }}>PIN ใหม่:</span>
      <input style={{ width: '110px', padding: '.3rem .5rem', borderRadius: '6px',
        border: '1.5px solid #a78bfa', fontFamily: 'inherit', fontSize: '.85rem' }}
        value={val} onChange={e => setVal(e.target.value)} autoFocus />
      <button type="button" {...ui('btn btn-sm btn-primary')}
        onClick={() => { onSave(val); setEditing(false); }}>บันทึก</button>
      <button type="button" {...ui('btn btn-sm')}
        onClick={() => setEditing(false)}>ยกเลิก</button>
    </div>
  );
}

function AttendanceView({ students, draft, updateDraft, recordDate, loadDraftForDate, isSaved, dateLabel, onSave, onBack }) {
  return (
    <div {...ui('animate-fade')}>
      <div {...ui('page-header')}>
        <h2>📝 บันทึกการมาเรียน</h2>
        <button type="button" {...ui('btn')} onClick={onBack}>← ย้อนกลับ</button>
      </div>
      <div {...ui('glass-card mb-4', { background: '#faf9ff' })}>
        <div {...ui('flex gap-2 items-center flex-wrap mb-3')}>
          <span {...ui('font-bold text-sm')}>📅 วันที่:</span>
          <input type="date" {...ui('input', { width: '180px' })} value={recordDate}
            onChange={e => loadDraftForDate(e.target.value)} />
          <span {...ui('text-sm text-muted')}>({dateLabel})</span>
        </div>
        <div {...ui('alert ' + (isSaved ? 'alert-success' : 'alert-info') + ' text-sm')}>
          {isSaved ? '✅ บันทึกแล้วสำหรับวันที่เลือก' : 'ℹ️ ยังไม่ได้บันทึก — กด "บันทึกการมาเรียน" ด้านล่าง'}
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '.6rem', marginBottom: '5rem' }}>
        {students.map((s, i) => {
          const att = draft[s.id]?.attendance ?? 'มา';
          const c   = ATT_COLOR[att] ?? { bg: '#f5f3ff', color: '#6b7280' };
          return (
            <div key={s.id} {...ui('glass-card', { padding: '.9rem 1.1rem', display: 'flex', alignItems: 'center', gap: '1rem' })}>
              <div {...ui('student-avatar', { background: c.bg, color: c.color, fontSize: '1rem', fontWeight: 800 })}>
                {i + 1}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div {...ui('font-bold', { fontSize: '.95rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' })}>
                  {s.name}
                </div>
                <span {...ui('badge badge-' + (s.level?.toLowerCase()), { marginTop: '.2rem' })}>{s.level}</span>
              </div>
              <select {...ui('input', { width: '110px', fontWeight: 700, background: c.bg, color: c.color, border: 'none' })}
                value={att} onChange={e => updateDraft(s.id, { attendance: e.target.value })}>
                {ATT_OPTS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          );
        })}
      </div>
      <div {...ui('flex justify-end gap-2', { position: 'sticky', bottom: 16 })}>
        <button type="button" {...ui('btn')} onClick={onBack}>ยกเลิก</button>
        <button type="button" {...ui('btn btn-primary')} onClick={onSave}>✅ บันทึกการมาเรียน</button>
      </div>
    </div>
  );
}

function HygieneView({ students, draft, updateDraft, recordDate, loadDraftForDate, onSave, onBack }) {
  return (
    <div {...ui('animate-fade')}>
      <div {...ui('page-header')}>
        <h2>🥛 บันทึกกิจวัตรประจำวัน</h2>
        <button type="button" {...ui('btn')} onClick={onBack}>← ย้อนกลับ</button>
      </div>
      <div {...ui('glass-card mb-4', { background: '#faf9ff' })}>
        <div {...ui('flex gap-2 items-center flex-wrap')}>
          <span {...ui('font-bold text-sm')}>📅 วันที่:</span>
          <input type="date" {...ui('input', { width: '180px' })} value={recordDate}
            onChange={e => loadDraftForDate(e.target.value)} />
        </div>
      </div>
      {/* ── ปุ่มเลือกทั้งหมด ── */}
      <div {...ui('glass-card mb-3', { padding: '.75rem 1rem', background: '#f0fdf4' })}>
        <div style={{ fontSize: '.8rem', fontWeight: 800, color: '#166534', marginBottom: '.5rem' }}>
          ⚡ เลือกทั้งหมด
        </div>
        <div style={{ display: 'flex', gap: '.5rem', flexWrap: 'wrap' }}>
          <button type="button" {...ui('btn btn-sm', { background: '#d1fae5', color: '#065f46', fontWeight: 700 })}
            onClick={() => students.forEach(s => updateDraft(s.id, { milk: true, brush: true }))}>
            🥛🪥 เลือกทั้งหมด (นม + แปรงฟัน)
          </button>
          <button type="button" {...ui('btn btn-sm', { background: '#dcfce7', color: '#166534', fontWeight: 700 })}
            onClick={() => students.forEach(s => updateDraft(s.id, { milk: true }))}>
            🥛 เลือกทั้งหมด (นม)
          </button>
          <button type="button" {...ui('btn btn-sm', { background: '#dbeafe', color: '#1e40af', fontWeight: 700 })}
            onClick={() => students.forEach(s => updateDraft(s.id, { brush: true }))}>
            🪥 เลือกทั้งหมด (แปรงฟัน)
          </button>
          <button type="button" {...ui('btn btn-sm', { background: '#f3f4f6', color: '#6b7280', fontWeight: 700, marginLeft: 'auto' })}
            onClick={() => students.forEach(s => updateDraft(s.id, { milk: false, brush: false }))}>
            ✕ ยกเลิกทั้งหมด
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '.6rem', marginBottom: '5rem' }}>
        {students.map(s => (
          <div key={s.id} {...ui('glass-card', { padding: '.9rem 1.1rem' })}>
            <div {...ui('flex items-center gap-3 mb-3')}>
              <div {...ui('student-avatar', { background: '#ede9fe', color: '#7c3aed' })}>🧒</div>
              <div>
                <div {...ui('font-bold', { fontSize: '.95rem' })}>{s.name}</div>
                <span {...ui('badge badge-' + (s.level?.toLowerCase()))}>{s.level}</span>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '.5rem' }}>
              <label style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '.3rem',
                padding: '.6rem', borderRadius: '12px', cursor: 'pointer',
                background: draft[s.id]?.milk ? '#d1fae5' : '#f5f3ff',
                border: '2px solid ' + (draft[s.id]?.milk ? '#10b981' : 'transparent'),
                transition: 'all .15s',
              }}>
                <span style={{ fontSize: '1.4rem' }}>🥛</span>
                <span style={{ fontSize: '.72rem', fontWeight: 700, color: draft[s.id]?.milk ? '#065f46' : '#6b7280' }}>ดื่มนม</span>
                <input type="checkbox" checked={Boolean(draft[s.id]?.milk)}
                  onChange={e => updateDraft(s.id, { milk: e.target.checked })} style={{ display: 'none' }} />
              </label>
              <label style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '.3rem',
                padding: '.6rem', borderRadius: '12px', cursor: 'pointer',
                background: draft[s.id]?.brush ? '#dbeafe' : '#f5f3ff',
                border: '2px solid ' + (draft[s.id]?.brush ? '#3b82f6' : 'transparent'),
                transition: 'all .15s',
              }}>
                <span style={{ fontSize: '1.4rem' }}>🪥</span>
                <span style={{ fontSize: '.72rem', fontWeight: 700, color: draft[s.id]?.brush ? '#1e40af' : '#6b7280' }}>แปรงฟัน</span>
                <input type="checkbox" checked={Boolean(draft[s.id]?.brush)}
                  onChange={e => updateDraft(s.id, { brush: e.target.checked })} style={{ display: 'none' }} />
              </label>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '.3rem' }}>
                <span style={{ fontSize: '1.4rem' }}>🍱</span>
                <select style={{
                  border: '1.5px solid #e8e3f4', borderRadius: '8px', fontSize: '.72rem', fontWeight: 700,
                  padding: '.25rem', textAlign: 'center', width: '100%', background: '#fef3c7',
                  color: '#92400e', fontFamily: 'inherit', cursor: 'pointer',
                }} value={draft[s.id]?.lunch ?? 'หมด'}
                  onChange={e => updateDraft(s.id, { lunch: e.target.value })}>
                  {LUNCH_OPTS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div {...ui('flex justify-end gap-2', { position: 'sticky', bottom: 16 })}>
        <button type="button" {...ui('btn')} onClick={onBack}>ยกเลิก</button>
        <button type="button" {...ui('btn btn-success')} onClick={onSave}>✅ บันทึกกิจวัตร</button>
      </div>
    </div>
  );
}

function buildDraft(students, dailyRecords, date) {
  const d = {};
  students.forEach(s => {
    const r = getDayRecord(dailyRecords, date, s.id);
    d[s.id] = { attendance: r?.attendance ?? 'มา', milk: r?.milk ?? true, brush: r?.brush ?? true, lunch: r?.lunch ?? 'หมด' };
  });
  return d;
}

/* ── StudentList — shared between main tab and students tab ─────────────────── */
function StudentList({ myStudents, filtered, search, setSearch, myClass, today, dailyRecords,
  setSelectedStudent, setEvaluatingStudent, setEditingStudentLocal, handleDelete }) {
  const { handleImport, setStudents } = useApp();
  const fileInputRef = useRef(null);
  const [dropOpen, setDropOpen] = useState(false);
  const dropRef = useRef(null);

  // ปิด dropdown เมื่อคลิกนอก
  useEffect(() => {
    if (!dropOpen) return;
    const handler = (e) => { if (dropRef.current && !dropRef.current.contains(e.target)) setDropOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [dropOpen]);

  const handleFileImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const raw = ev.target.result.replace(/^\ufeff/, '');
      const r = handleImport('students', raw);
      alert(r.ok ? `✅ นำเข้าสำเร็จ! เพิ่มนักเรียน ${r.count ?? ''} คน` : r.message);
    };
    reader.readAsText(file, 'utf-8');
    e.target.value = '';
    setDropOpen(false);
  };

  const handleDownloadTemplate = () => {
    const headers = 'ชื่อ-นามสกุล,ชื่อเล่น,เพศ,เลขประจำตัว,เลขบัตรประชาชน,ระดับ,ห้องเรียน,วันเกิด,อายุ,น้ำหนัก,ส่วนสูง,parentPin,ชื่อบิดา,อาชีพบิดา,ชื่อมารดา,อาชีพมารดา,เบอร์ผู้ปกครอง,ที่อยู่';
    const blob = new Blob(['﻿' + headers + '\n'], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'template_นักเรียน.csv'; a.click();
    URL.revokeObjectURL(url);
    setDropOpen(false);
  };

  const handleSetPinFromId = () => {
    if (!window.confirm('ตั้ง PIN ของนักเรียนทุกคนเป็นเลขประจำตัวนักเรียน (studentId) ใช่หรือไม่?')) return;
    setStudents(prev => prev.map(s => ({
      ...s,
      parentPin: String(s.studentId || s.code || s.id),
    })));
    alert('✅ ตั้ง PIN เสร็จแล้ว');
    setDropOpen(false);
  };

  const menuLabel = { fontSize: '.68rem', fontWeight: 800, color: '#94a3b8',
    textTransform: 'uppercase', letterSpacing: '.05em', padding: '.45rem .85rem .2rem' };
  const menuItem = { display: 'flex', alignItems: 'center', gap: '.55rem',
    padding: '.52rem .85rem', cursor: 'pointer', fontSize: '.85rem', fontWeight: 600,
    color: '#1e293b', background: 'none', border: 'none', width: '100%', textAlign: 'left',
    transition: 'background .12s' };

  return (
    <div {...ui('glass', { padding: '1.5rem' })}>
      <div {...ui('page-header', { marginBottom: '1rem' })}>
        <h3>👨‍🎓 รายชื่อนักเรียน{myClass ? ` ห้อง ${myClass}` : ''} ({filtered.length}/{myStudents.length} คน)</h3>
        <div style={{ display: 'flex', gap: '.5rem', alignItems: 'center' }}>
          <input {...ui('input', { maxWidth: '220px' })} placeholder="🔍 ค้นหาชื่อ..."
            value={search} onChange={e => setSearch(e.target.value)} />
          <input ref={fileInputRef} type="file" accept=".csv" style={{ display: 'none' }}
            onChange={handleFileImport} />

          {/* ── Dropdown นำเข้าข้อมูล ── */}
          <div ref={dropRef} style={{ position: 'relative' }}>
            <button type="button" {...ui('btn', { background: '#f0f9ff', color: '#0369a1', fontWeight: 700, whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: '.35rem' })}
              onClick={() => setDropOpen(v => !v)}>
              📥 นำเข้าข้อมูล
              <span style={{ fontSize: '.7rem', opacity: .7 }}>{dropOpen ? '▲' : '▼'}</span>
            </button>

            {dropOpen && (
              <div style={{
                position: 'absolute', right: 0, top: 'calc(100% + 6px)', zIndex: 200,
                background: '#fff', borderRadius: '14px', minWidth: '210px',
                boxShadow: '0 8px 32px rgba(0,0,0,.13)', border: '1px solid #e2e8f0',
                overflow: 'hidden',
              }}>
                {/* ── ไฟล์ ── */}
                <div style={menuLabel}>ไฟล์</div>
                <button type="button" style={menuItem}
                  onMouseEnter={e => e.currentTarget.style.background='#f8fafc'}
                  onMouseLeave={e => e.currentTarget.style.background='none'}
                  onClick={handleDownloadTemplate}>
                  📋 ดาวน์โหลด Template CSV
                </button>
                <button type="button" style={menuItem}
                  onMouseEnter={e => e.currentTarget.style.background='#f8fafc'}
                  onMouseLeave={e => e.currentTarget.style.background='none'}
                  onClick={() => fileInputRef.current?.click()}>
                  📂 นำเข้าจาก CSV
                </button>

                {/* ── เครื่องมือ ── */}
                <div style={{ ...menuLabel, borderTop: '1px solid #f1f5f9', marginTop: '.25rem' }}>เครื่องมือ</div>
                <button type="button" style={{ ...menuItem, marginBottom: '.35rem' }}
                  onMouseEnter={e => e.currentTarget.style.background='#f8fafc'}
                  onMouseLeave={e => e.currentTarget.style.background='none'}
                  onClick={handleSetPinFromId}>
                  🔑 ตั้ง PIN = รหัสประจำตัว
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '.6rem' }}>
        {filtered.map(s => {
          const isInactive = (s.status ?? 'ปกติ') === 'นอกระบบ';
          const rec   = getDayRecord(dailyRecords, today, s.id);
          const hygOk = hasHygieneToday(rec);
          const att   = rec?.attendance;
          const ac    = att ? (ATT_COLOR[att] ?? { bg: '#f5f3ff', color: '#6b7280' }) : null;
          const isBoy = s.name.includes('ชาย');
          const pct   = s.attendance?.total
            ? Math.round((s.attendance.present / s.attendance.total) * 100) : 0;
          return (
            <div key={s.id} {...ui('student-card', { display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap', opacity: isInactive ? 0.6 : 1 })}>
              <div {...ui('student-avatar', {
                  background: isInactive ? '#f3f4f6' : (isBoy ? '#dbeafe' : '#fce7f3'),
                  color: isInactive ? '#9ca3af' : (isBoy ? '#1e40af' : '#9d174d'),
                  overflow: 'hidden',
                })}>
                {isInactive ? '⛔'
                  : s.photo
                    ? <img src={s.photo} alt={s.name} style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                    : (isBoy ? '👦' : '👧')}
              </div>
              <div style={{ flex: 1, minWidth: '130px' }}>
                <div {...ui('font-bold', { fontSize: '.92rem' })}>{s.name}</div>
                <div {...ui('flex gap-1 mt-1', { flexWrap: 'wrap' })}>
                  <span {...ui('badge badge-' + (s.level?.toLowerCase()))}>{s.level}</span>
                  {isInactive && <span {...ui('badge', { background: '#f3f4f6', color: '#6b7280' })}>นอกระบบ</span>}
                  {!isInactive && att && <span {...ui('badge', { background: ac?.bg, color: ac?.color })}>{att}</span>}
                  {!isInactive && hygOk && <><span {...ui('badge badge-success')}>🥛</span><span {...ui('badge badge-info')}>🪥</span></>}
                </div>
              </div>
              {!isInactive && (
                <div style={{ textAlign: 'center', minWidth: '52px' }}>
                  <div style={{ fontSize: '1rem', fontWeight: 800,
                    color: pct >= 80 ? 'var(--success)' : pct >= 60 ? 'var(--accent)' : 'var(--danger)' }}>
                    {pct}%
                  </div>
                  <div {...ui('text-xs text-muted')}>มาเรียน</div>
                </div>
              )}
              {!isInactive && (
                <div style={{ textAlign: 'center', minWidth: '48px' }}>
                  {s.assessments?.summary
                    ? <div style={{ color: 'var(--success)', fontSize: '1.25rem' }}>✅</div>
                    : <div style={{ color: '#d1d5db', fontSize: '1.25rem' }}>○</div>}
                  <div {...ui('text-xs text-muted')}>ประเมิน</div>
                </div>
              )}
              <div {...ui('flex gap-1', { flexWrap: 'wrap' })}>
                <button type="button" {...ui('btn btn-sm', { background: '#ede9fe', color: 'var(--primary)' })}
                  onClick={() => setSelectedStudent(s)}>📄</button>
                <button type="button" {...ui('btn btn-sm', { background: '#fef9c3', color: '#92400e' })}
                  onClick={() => setEditingStudentLocal(s)}>✏️</button>
                {!isInactive && (
                  <button type="button" {...ui('btn btn-sm btn-primary')}
                    onClick={() => setEvaluatingStudent(s)}>📊</button>
                )}
                <button type="button" {...ui('btn btn-sm', { color: 'var(--danger)' })}
                  onClick={() => handleDelete(s.id)}>🗑️</button>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div {...ui('text-center text-muted', { padding: '3rem 1rem' })}>
            ไม่พบนักเรียนที่ค้นหา
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function TeacherDashboard() {
  const {
    students, setStudents,
    setSelectedStudent, setEvaluatingStudent,
    handleImport, announcements, setAnnouncements, dailyRecords,
    saveDailyAttendance, saveDailyHygiene,
    user, teachers, setTeachers,
    menuPermissions,
  } = useApp();

  // ── กรอง tab ตาม menuPermissions ของ user ที่ login อยู่ ──
  const userId = String(user?.teacherId ?? user?.id ?? '');
  const userPerm = menuPermissions?.[userId] ?? {};
  const visibleTabGroups = useMemo(() =>
    TEACHER_TAB_GROUPS
      .map(g => ({ ...g, tabs: g.tabs.filter(t => userPerm[t.id] !== false) }))
      .filter(g => g.tabs.length > 0),
    [userPerm]
  );

  const [activeTab,  setActiveTab]  = useState(() => localStorage.getItem('kt_teacherTab') || 'main');
  const [activeView, setActiveView] = useState('main');
  const [recordDate, setRecordDate] = useState(todayISO());

  /* ── Local student add / edit ── */
  const [isAddingLocal,       setIsAddingLocal]       = useState(false);
  const [editingStudentLocal, setEditingStudentLocal] = useState(null);

  /* ── Profile edit ── */
  const myTeacher  = teachers?.find(t => t.id === (user?.teacherId ?? user?.id));
  const [profileForm,    setProfileForm]    = useState(null);
  const [profileSaved,   setProfileSaved]   = useState(false);
  const [photoUploading, setPhotoUploading] = useState(false);

  async function handlePhotoUpload(file) {
    if (!file || !storage) return;
    setPhotoUploading(true);
    try {
      const ext  = file.name.split('.').pop();
      const path = `teacher-photos/${myTeacher?.id ?? 'unknown'}.${ext}`;
      const sRef = ref(storage, path);
      await uploadBytes(sRef, file);
      const url  = await getDownloadURL(sRef);
      setTeachers(ts => ts.map(t => t.id === myTeacher?.id ? { ...t, photoURL: url } : t));
      setProfileForm(f => f ? { ...f, photoURL: url } : f);
    } catch (err) {
      console.error('upload photo error:', err);
    } finally {
      setPhotoUploading(false);
    }
  }

  /* ── Teacher announce state ── */
  const [annTitle, setAnnTitle] = useState('');
  const [annBody,  setAnnBody]  = useState('');
  const [annSaved, setAnnSaved] = useState(false);

  /* ── Students filtered to teacher's class ── */
  const myClass    = user?.className;
  const myStudents = useMemo(
    () => students
      .filter(s => s.className === myClass && !s.name.startsWith('(ว่าง)'))
      .sort((a, b) => (a.name ?? '').localeCompare(b.name ?? '', 'th')),
    [students, myClass],
  );
  const activeStudents = useMemo(
    () => myStudents.filter(s => isStudentActive(s, recordDate)),
    [myStudents, recordDate],
  );

  /* ── Announcements visible to this teacher ── */
  const allMyAnnouncements = useMemo(
    () => (announcements ?? [])
      .filter(a => !a.target || a.target === 'all' || a.target === myClass),
    [announcements, myClass],
  );
  // Banner in main tab: show latest 1 only
  const myAnnouncements = allMyAnnouncements.slice(0, 1);

  const [draft,  setDraft]  = useState(() => buildDraft(activeStudents, dailyRecords, todayISO()));
  const [search, setSearch] = useState('');

  const today     = todayISO();
  const dateLabel = formatDateThai(recordDate);

  const isSaved = useMemo(
    () => activeStudents.every(s => getDayRecord(dailyRecords, recordDate, s.id)?.attendance),
    [activeStudents, dailyRecords, recordDate],
  );

  const filtered = useMemo(
    () => myStudents.filter(s => s.name.includes(search.trim())),
    [myStudents, search],
  );

  const stats = useMemo(() => ({
    total:    activeStudents.length,
    attend:   activeStudents.filter(s => getDayRecord(dailyRecords, today, s.id)?.attendance === 'มา').length,
    hygiene:  activeStudents.filter(s => hasHygieneToday(getDayRecord(dailyRecords, today, s.id))).length,
    assessed: activeStudents.filter(s => s.assessments?.summary).length,
  }), [activeStudents, dailyRecords, today]);

  // ── Monthly attendance chart (auto-slide) ─────────────────────────────
  const THAI_M_SHORT = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
  const monthlyChartData = useMemo(() => {
    const now    = new Date();
    const todayS = todayISO();
    const result = [];
    for (let offset = 0; offset < 4; offset++) {
      const d          = new Date(now.getFullYear(), now.getMonth() - offset, 1);
      const year       = d.getFullYear();
      const month      = d.getMonth();
      const daysInMon  = new Date(year, month + 1, 0).getDate();
      const monthISO   = `${year}-${String(month + 1).padStart(2, '0')}`;
      const label      = `${THAI_M_SHORT[month]} ${year + 543}`;

      const bars = [];
      for (let day = 1; day <= daysInMon; day++) {
        const dateISO = `${monthISO}-${String(day).padStart(2, '0')}`;
        if (dateISO > todayS) break;
        const dow = new Date(dateISO).getDay();
        if (dow === 0 || dow === 6) continue;

        const activeOnDay = myStudents.filter(s => isStudentActive(s, dateISO));
        if (activeOnDay.length === 0) continue;

        const hasRecord = activeOnDay.some(s => getDayRecord(dailyRecords, dateISO, s.id)?.attendance);
        if (!hasRecord) { bars.push({ day, dateISO, pct: null }); continue; }

        const present = activeOnDay.filter(s => getDayRecord(dailyRecords, dateISO, s.id)?.attendance === 'มา').length;
        bars.push({ day, dateISO, pct: Math.round(present / activeOnDay.length * 100) });
      }

      const recorded = bars.filter(b => b.pct !== null);
      const avgPct   = recorded.length > 0
        ? Math.round(recorded.reduce((s, b) => s + b.pct, 0) / recorded.length)
        : null;
      result.push({ label, monthISO, bars, avgPct });
    }
    return result.filter(m => m.bars.length > 0);
  }, [myStudents, dailyRecords]);

  const [slideIdx, setSlideIdx] = useState(0);
  useEffect(() => {
    if (monthlyChartData.length <= 1) return;
    const t = setInterval(() => setSlideIdx(i => (i + 1) % monthlyChartData.length), 5000);
    return () => clearInterval(t);
  }, [monthlyChartData.length]);

  const loadDraft   = date => { setRecordDate(date); setDraft(buildDraft(activeStudents, dailyRecords, date)); };
  const updateDraft = (id, patch) => setDraft(prev => ({ ...prev, [id]: { ...prev[id], ...patch } }));

  const saveAttendance = () => {
    const rec = {};
    activeStudents.forEach(s => { rec[String(s.id)] = { attendance: draft[s.id]?.attendance ?? 'มา' }; });
    saveDailyAttendance(recordDate, rec);
    alert('บันทึกการมาเรียนเรียบร้อยแล้ว ✅');
    setActiveView('main');
  };

  const saveHygiene = () => {
    const rec = {};
    activeStudents.forEach(s => {
      const d = draft[s.id];
      rec[String(s.id)] = { milk: Boolean(d?.milk), brush: Boolean(d?.brush), lunch: d?.lunch ?? 'หมด' };
    });
    saveDailyHygiene(recordDate, rec);
    alert('บันทึกกิจวัตรประจำวันเรียบร้อยแล้ว ✅');
    setActiveView('main');
  };

  const handleDelete = id => {
    if (confirm('คุณต้องการลบข้อมูลนักเรียนรายนี้ใช่หรือไม่?'))
      setStudents(students.filter(s => s.id !== id));
  };

  const handleAddStudentLocal = data => {
    setStudents(prev => [...prev, {
      ...data, id: Date.now(), className: myClass,
      status: data.status || 'ปกติ', assessments: {},
      attendance: { present: 0, absent: 0, total: 0 },
      parentPin: data.parentPin || String(1000 + Math.floor(Math.random() * 9000)),
    }]);
    setIsAddingLocal(false);
  };

  const handleEditStudentLocal = data => {
    setStudents(students.map(s => s.id === editingStudentLocal.id ? { ...s, ...data } : s));
    setEditingStudentLocal(null);
  };

  /* ── Full-page attendance / hygiene views (no sidebar) ── */
  if (activeView === 'attendance')
    return <AttendanceView students={activeStudents} draft={draft} updateDraft={updateDraft}
      recordDate={recordDate} loadDraftForDate={loadDraft} isSaved={isSaved} dateLabel={dateLabel}
      onSave={saveAttendance} onBack={() => setActiveView('main')} />;

  if (activeView === 'hygiene')
    return <HygieneView students={activeStudents} draft={draft} updateDraft={updateDraft}
      recordDate={recordDate} loadDraftForDate={loadDraft}
      onSave={saveHygiene} onBack={() => setActiveView('main')} />;

  /* ── SOCIAL fields for profile ── */
  const SOCIAL = [
    { key: 'line',      label: 'LINE',      placeholder: '@lineId' },
    { key: 'facebook',  label: 'Facebook',  placeholder: 'ชื่อเพจ/โปรไฟล์' },
    { key: 'instagram', label: 'Instagram', placeholder: '@username' },
    { key: 'tiktok',    label: 'TikTok',    placeholder: '@username' },
    { key: 'youtube',   label: 'YouTube',   placeholder: 'ชื่อช่อง' },
  ];

  /* ── Main sidebar layout ── */
  return (
    <div {...ui('animate-fade', { display: 'flex', gap: '1rem', alignItems: 'flex-start' })}>

      {/* ── Left sidebar ── */}
      <DashboardSidebar
        groups={visibleTabGroups}
        activeTab={activeTab}
        onTabChange={(tab) => { setActiveTab(tab); localStorage.setItem('kt_teacherTab', tab); }}
        badge={myClass ? `🏫 ห้อง ${myClass}` : undefined}
      />

      {/* ── Main content ── */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <ErrorBoundary>
        <Suspense fallback={
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9ca3af', fontSize: '.9rem' }}>
            กำลังโหลด…
          </div>
        }>

          {/* ── Overview (daily checklist) ── */}
          {activeTab === 'overview'    && (
            <TeacherOverviewTab
              onTabChange={tab => {
                setActiveTab(tab);
                localStorage.setItem('kt_teacherTab', tab);
              }}
            />
          )}
          {activeTab === 'attendance'  && <AdminAttTab defaultClass={myClass} />}
          {activeTab === 'pickup'      && <PickupTab defaultClass={myClass} />}
          {activeTab === 'healthcheck'  && <HealthCheckTab teacherClassFilter={myClass} />}
          {activeTab === 'illnesscheck' && <IllnessCheckTab teacherClassFilter={myClass} />}
          {activeTab === 'toothbrush'   && <ToothBrushTab teacherClassFilter={myClass} />}
          {activeTab === 'lunch'        && <LunchTab teacherClassFilter={myClass} />}
          {activeTab === 'milk'         && <MilkTab teacherClassFilter={myClass} />}
          {activeTab === 'nutrition'     && <NutritionTab teacherClassFilter={myClass} />}
          {activeTab === 'dailyroutine'  && <DailyRoutineTab teacherClassFilter={myClass} />}
          {activeTab === 'specialevent'  && <SpecialEventTab teacherClassFilter={myClass} />}

          {/* ── Learning results ── */}
          {activeTab === 'studentreport' && <StudentReportTab teacherClassFilter={myClass} />}
          {activeTab === 'evaluation'    && <EvaluationTab />}
          {activeTab === 'abilityassess' && <AbilityAssessmentTab teacherClassFilter={myClass} />}
          {activeTab === 'formreports'   && <ReportsTab teacherClassFilter={myClass} />}
          {activeTab === 'activitylog'   && <ActivityLogTab />}

          {/* ── Media & environment ── */}
          {activeTab === 'mediaborrow' && <MediaBorrowTab teacherClassFilter={myClass} />}
          {activeTab === 'media'       && <MediaTab teacherClassFilter={myClass} viewMode="entry" />}
          {activeTab === 'corner'      && <CornerTab teacherClassFilter={myClass} />}
          {activeTab === 'innercorner' && <InnerCornerTab teacherClassFilter={myClass} />}
          {activeTab === 'devreport'   && <DevelopmentalReportTab teacherClassFilter={myClass} />}

          {/* ── Standards ── */}
          {activeTab === 'std2self'    && <Std2SelfTab />}
          {activeTab === 'nationalstd' && <NationalStandardsTab />}
          {activeTab === 'indicators'  && <IndicatorsTab readOnly={true} />}
          {activeTab === 'aichat'      && <AIChatTab />}
          {activeTab === 'help'        && <HelpTab />}
          {activeTab === 'standards'   && (
            <div {...ui('glass p-6')}>
              <h3 {...ui('mb-6')}>🗺️ สรุปมาตรฐานสถานพัฒนาเด็กปฐมวัย (ปี 2569)</h3>
              <QaStandardView />
            </div>
          )}

          {/* ── PIN tab ── */}
          {activeTab === 'pins' && (
            <div {...ui('glass p-6 animate-fade')}>
              <div {...ui('page-header mb-4')}>
                <h3>🔑 รหัส PIN ผู้ปกครอง</h3>
                <span style={{
                  background: '#ede9fe', color: '#7c3aed',
                  borderRadius: '999px', padding: '.22rem .85rem',
                  fontSize: '.78rem', fontWeight: 800,
                }}>ห้อง {myClass} · {myStudents.length} คน</span>
              </div>
              <p style={{ fontSize: '.83rem', color: '#6b7280', marginBottom: '1.25rem' }}>
                แก้ไข PIN สำหรับผู้ปกครองใช้เข้าสู่ระบบดูข้อมูลบุตรหลาน (ห้อง {myClass})
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '.5rem' }}>
                {myStudents.length === 0 ? (
                  <div style={{ textAlign: 'center', color: '#9ca3af', padding: '2rem 0', fontSize: '.85rem' }}>
                    ยังไม่มีนักเรียนในห้องนี้
                  </div>
                ) : myStudents.map(s => (
                  <StudentPinRow key={s.id} student={s}
                    onSave={pin => setStudents(prev => prev.map(x => x.id === s.id ? { ...x, parentPin: pin } : x))} />
                ))}
              </div>
            </div>
          )}

          {/* ── Announce tab ── */}
          {activeTab === 'teacherannounce' && (
            <div {...ui('glass p-6 animate-fade')}>
              <div {...ui('page-header mb-4')}>
                <h3>📢 ประกาศ</h3>
                {myClass && (
                  <span style={{ background: '#ede9fe', color: '#7c3aed', borderRadius: '999px', padding: '.22rem .85rem', fontSize: '.78rem', fontWeight: 800 }}>
                    ห้อง {myClass}
                  </span>
                )}
              </div>
              <div style={{ background: '#faf5ff', border: '1.5px solid #ede9fe', borderRadius: '14px', padding: '1.25rem 1.5rem', marginBottom: '1.5rem' }}>
                <div style={{ fontWeight: 700, color: '#7c3aed', marginBottom: '.85rem', fontSize: '.88rem' }}>
                  ✍️ สร้างประกาศ{myClass ? ` (ห้อง ${myClass})` : ''}
                </div>
                <div style={{ marginBottom: '.7rem' }}>
                  <label style={{ display: 'block', fontWeight: 700, fontSize: '.82rem', color: '#374151', marginBottom: '.35rem' }}>หัวข้อ *</label>
                  <input {...ui('input')} placeholder="หัวข้อประกาศ..." value={annTitle} onChange={e => setAnnTitle(e.target.value)} />
                </div>
                <div style={{ marginBottom: '1rem' }}>
                  <label style={{ display: 'block', fontWeight: 700, fontSize: '.82rem', color: '#374151', marginBottom: '.35rem' }}>รายละเอียด (ไม่บังคับ)</label>
                  <textarea {...ui('input', { resize: 'vertical', fontFamily: 'inherit' })} rows={3} placeholder="รายละเอียดเพิ่มเติม..." value={annBody}
                    onChange={e => setAnnBody(e.target.value)} />
                </div>
                {annSaved && <div {...ui('alert alert-success mb-3')}>✅ เพิ่มประกาศเรียบร้อยแล้ว</div>}
                <button type="button" {...ui('btn btn-primary', undefined, undefined, !annTitle.trim())} disabled={!annTitle.trim()}
                  onClick={() => {
                    if (!annTitle.trim()) return;
                    const now  = new Date();
                    const date = now.toLocaleDateString('th-TH', { day: '2-digit', month: '2-digit', year: 'numeric', calendar: 'buddhist' });
                    setAnnouncements([
                      { id: Date.now(), date, title: annTitle.trim(), body: annBody.trim(), target: myClass ?? 'all' },
                      ...(announcements ?? []),
                    ]);
                    setAnnTitle(''); setAnnBody('');
                    setAnnSaved(true);
                    setTimeout(() => setAnnSaved(false), 2500);
                  }}>
                  📢 ประกาศ
                </button>
              </div>
              <div style={{ fontWeight: 700, color: '#374151', marginBottom: '.85rem', fontSize: '.88rem' }}>
                📋 ประกาศล่าสุด (ที่เกี่ยวกับห้อง {myClass})
              </div>
              {allMyAnnouncements.length === 0 ? (
                <div {...ui('text-center text-muted', { padding: '2rem' })}>ยังไม่มีประกาศ</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '.7rem' }}>
                  {allMyAnnouncements.map((a, idx) => (
                    <div key={a.id} style={{
                      display: 'flex', gap: '1rem', alignItems: 'flex-start',
                      padding: '1rem 1.25rem', borderRadius: '12px',
                      background: idx === 0 ? '#faf5ff' : 'white',
                      border: `1.5px solid ${idx === 0 ? '#ddd6fe' : '#e5e7eb'}`,
                    }}>
                      <div style={{ fontSize: '1.4rem', marginTop: '.1rem' }}>📢</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', gap: '.4rem', alignItems: 'center', flexWrap: 'wrap', marginBottom: '.3rem' }}>
                          {idx === 0 && <span style={{ background: '#7c3aed', color: 'white', fontSize: '.65rem', fontWeight: 800, padding: '1px 8px', borderRadius: '999px' }}>ล่าสุด</span>}
                          {(!a.target || a.target === 'all') ? (
                            <span style={{ background: '#dbeafe', color: '#1e40af', fontSize: '.68rem', fontWeight: 700, padding: '1px 8px', borderRadius: '999px' }}>ทุกคน</span>
                          ) : (
                            <span style={{ background: '#ede9fe', color: '#7c3aed', fontSize: '.68rem', fontWeight: 700, padding: '1px 8px', borderRadius: '999px' }}>ห้อง {a.target}</span>
                          )}
                          <span style={{ fontSize: '.72rem', color: '#9ca3af' }}>📅 {a.date}</span>
                        </div>
                        <div style={{ fontWeight: 700, fontSize: '.9rem', color: '#111827', marginBottom: a.body ? '.3rem' : 0 }}>{a.title}</div>
                        {a.body && <div style={{ fontSize: '.83rem', color: '#4b5563', lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{a.body}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── Students tab ── */}
          {activeTab === 'students' && (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: '.75rem', marginBottom: '1.25rem' }}>
                <button type="button" {...ui('btn', { background: '#dbeafe', color: '#1e40af', padding: '.85rem', fontSize: '.9rem', borderRadius: '14px' })}
                  onClick={() => {
                    const text = prompt('วางข้อมูล CSV (ชื่อ, ชั้น, อายุ, น้ำหนัก, ส่วนสูง)\nเช่น: เด็กชายดีใจ, K3, 5, 18.5, 110');
                    if (text) {
                      const r = handleImport('students', 'name,level,age,weight,height\n' + text);
                      alert(r.ok ? 'นำเข้าข้อมูลสำเร็จ! ✅' : r.message);
                    }
                  }}>
                  📥 นำเข้าข้อมูล
                </button>
                <button type="button" {...ui('btn btn-primary', { padding: '.85rem', fontSize: '.9rem', borderRadius: '14px' })}
                  onClick={() => setIsAddingLocal(true)}>
                  ➕ เพิ่มนักเรียน
                </button>
              </div>
              <StudentList myStudents={myStudents} filtered={filtered} search={search} setSearch={setSearch}
                myClass={myClass} today={today} dailyRecords={dailyRecords}
                setSelectedStudent={setSelectedStudent} setEvaluatingStudent={setEvaluatingStudent}
                setEditingStudentLocal={setEditingStudentLocal} handleDelete={handleDelete} />
            </>
          )}

          {/* ── Profile tab ── */}
          {activeTab === 'profile' && (
            <div {...ui('glass p-6')}>
              <div {...ui('page-header mb-6')}>
                <h3>👤 ข้อมูลของฉัน</h3>
                {!profileForm && (
                  <button type="button" {...ui('btn btn-primary')}
                    onClick={() => { setProfileForm({ ...myTeacher }); setProfileSaved(false); }}>
                    ✏️ แก้ไขข้อมูล
                  </button>
                )}
              </div>
              {profileSaved && <div {...ui('alert alert-success mb-4')}>✅ บันทึกข้อมูลเรียบร้อยแล้ว</div>}
              {!profileForm ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '520px' }}>
                  {/* ── รูปโปรไฟล์ (view) ── */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '.5rem' }}>
                    <div style={{
                      width: 88, height: 88, borderRadius: '50%',
                      background: 'linear-gradient(135deg,#7c3aed,#a855f7)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      overflow: 'hidden', flexShrink: 0,
                      border: '3px solid #ede9fe', boxShadow: '0 2px 8px rgba(124,58,237,.15)',
                    }}>
                      {myTeacher?.photoURL
                        ? <img src={myTeacher.photoURL} alt="profile"
                            style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        : <span style={{ fontSize: '2.2rem' }}>👩‍🏫</span>
                      }
                    </div>
                    <div>
                      <div style={{ fontWeight: 800, fontSize: '1.05rem', color: '#1e293b' }}>
                        {myTeacher?.name ?? '—'}
                      </div>
                      <div style={{ fontSize: '.82rem', color: '#7c3aed', fontWeight: 600 }}>
                        {myTeacher?.className ?? ''}
                      </div>
                    </div>
                  </div>

                  <div style={{
                    display: 'flex', gap: '1rem', alignItems: 'center',
                    padding: '.6rem .85rem', borderRadius: '10px',
                    background: '#f1f5f9', border: '1.5px solid #e2e8f0',
                  }}>
                    <span style={{ minWidth: '100px', fontWeight: 700, color: '#6b7280', fontSize: '.85rem' }}>Username</span>
                    <code style={{ fontWeight: 700, fontSize: '.9rem', color: '#374151', letterSpacing: '.02em' }}>
                      {myTeacher?.username ?? '—'}
                    </code>
                    <span style={{ marginLeft: 'auto', fontSize: '.68rem', color: '#94a3b8', background: '#e2e8f0', padding: '2px 7px', borderRadius: '5px' }}>
                      🔒 แก้ไขไม่ได้
                    </span>
                  </div>
                  {[
                    { label: 'ชื่อ-นามสกุล', value: myTeacher?.name ?? '—' },
                    { label: 'E-mail',        value: myTeacher?.email ?? '—' },
                    { label: 'เบอร์โทร',      value: myTeacher?.phone ?? '—' },
                    { label: 'ห้องเรียน',     value: myTeacher?.className ?? '—' },
                  ].map(r => (
                    <div key={r.label} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                      <span style={{ minWidth: '100px', fontWeight: 700, color: '#6b7280', fontSize: '.85rem' }}>{r.label}</span>
                      <span style={{ fontWeight: 600 }}>{r.value}</span>
                    </div>
                  ))}
                  {SOCIAL.map(s => myTeacher?.[s.key] ? (
                    <div key={s.key} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                      <span style={{ minWidth: '100px', fontWeight: 700, color: '#6b7280', fontSize: '.85rem' }}>{s.label}</span>
                      <span style={{ fontWeight: 600 }}>{myTeacher[s.key]}</span>
                    </div>
                  ) : null)}
                </div>
              ) : (
                <form onSubmit={e => {
                  e.preventDefault();
                  const { _newPin, ...rest } = profileForm;
                  const patch = _newPin?.trim() ? { ...rest, pin: _newPin.trim() } : rest;
                  setTeachers(teachers.map(t => t.id === myTeacher.id ? { ...t, ...patch } : t));
                  setProfileForm(null);
                  setProfileSaved(true);
                }} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '520px' }}>

                  {/* ── รูปโปรไฟล์ (edit) ── */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
                    <div style={{
                      width: 80, height: 80, borderRadius: '50%',
                      background: 'linear-gradient(135deg,#7c3aed,#a855f7)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      overflow: 'hidden', flexShrink: 0,
                      border: '3px solid #ede9fe',
                    }}>
                      {(profileForm?.photoURL ?? myTeacher?.photoURL)
                        ? <img src={profileForm?.photoURL ?? myTeacher?.photoURL} alt="profile"
                            style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        : <span style={{ fontSize: '2rem' }}>👩‍🏫</span>
                      }
                    </div>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '.85rem', marginBottom: '.4rem' }}>
                        📷 รูปโปรไฟล์
                      </label>
                      <label style={{
                        display: 'inline-block', cursor: photoUploading ? 'not-allowed' : 'pointer',
                        background: '#7c3aed', color: 'white',
                        padding: '.35rem .85rem', borderRadius: '8px',
                        fontSize: '.8rem', fontWeight: 700,
                        opacity: photoUploading ? .6 : 1,
                      }}>
                        {photoUploading ? '⏳ กำลังอัปโหลด...' : '📁 เลือกรูป'}
                        <input type="file" accept="image/*" style={{ display: 'none' }}
                          disabled={photoUploading}
                          onChange={e => { if (e.target.files?.[0]) handlePhotoUpload(e.target.files[0]); }} />
                      </label>
                      <div style={{ fontSize: '.72rem', color: '#9ca3af', marginTop: '.3rem' }}>
                        JPG / PNG / WEBP · ไม่เกิน 5MB
                      </div>
                    </div>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '.35rem', fontWeight: 600, fontSize: '.85rem' }}>ชื่อ-นามสกุล *</label>
                    <input {...ui('input')} required value={profileForm.name ?? ''}
                      onChange={e => setProfileForm(f => ({ ...f, name: e.target.value }))} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '.35rem', fontWeight: 600, fontSize: '.85rem' }}>E-mail *</label>
                    <input {...ui('input')} type="email" required value={profileForm.email ?? ''}
                      onChange={e => setProfileForm(f => ({ ...f, email: e.target.value }))} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '.35rem', fontWeight: 600, fontSize: '.85rem' }}>เบอร์โทรศัพท์</label>
                    <input {...ui('input')} placeholder="0xx-xxx-xxxx" value={profileForm.phone ?? ''}
                      onChange={e => setProfileForm(f => ({ ...f, phone: e.target.value }))} />
                  </div>
                  <div style={{ borderTop: '1.5px solid #e5e7eb', paddingTop: '.75rem', marginTop: '.25rem' }}>
                    <div style={{ fontWeight: 700, fontSize: '.85rem', color: '#6b7280', marginBottom: '.75rem' }}>
                      📱 ช่องทางติดต่อ Social (ไม่บังคับ)
                    </div>
                    {SOCIAL.map(s => (
                      <div key={s.key} style={{ marginBottom: '.6rem' }}>
                        <label style={{ display: 'block', marginBottom: '.3rem', fontWeight: 600, fontSize: '.85rem' }}>{s.label}</label>
                        <input {...ui('input')} placeholder={s.placeholder} value={profileForm[s.key] ?? ''}
                          onChange={e => setProfileForm(f => ({ ...f, [s.key]: e.target.value }))} />
                      </div>
                    ))}
                  </div>
                  <div style={{ borderTop: '1.5px solid #e5e7eb', paddingTop: '.75rem', marginTop: '.25rem' }}>
                    <div style={{ fontWeight: 700, fontSize: '.85rem', color: '#6b7280', marginBottom: '.75rem' }}>
                      🔐 เปลี่ยนรหัสผ่าน Login
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.75rem' }}>
                      <div>
                        <label style={{ display: 'block', marginBottom: '.35rem', fontWeight: 600, fontSize: '.85rem' }}>Username</label>
                        <input {...ui('input', { background: '#f9fafb', color: '#6b7280' })} value={profileForm.username ?? ''} readOnly />
                      </div>
                      <div>
                        <label style={{ display: 'block', marginBottom: '.35rem', fontWeight: 600, fontSize: '.85rem' }}>รหัสผ่านใหม่</label>
                        <input {...ui('input')} placeholder="เว้นว่างถ้าไม่เปลี่ยน"
                          value={profileForm._newPin ?? ''}
                          onChange={e => setProfileForm(f => ({ ...f, _newPin: e.target.value }))} />
                      </div>
                    </div>
                  </div>
                  <div {...ui('flex gap-2 mt-2')}>
                    <button type="button" {...ui('btn flex-1')} onClick={() => setProfileForm(null)}>ยกเลิก</button>
                    <button type="submit" {...ui('btn btn-primary flex-1')}>💾 บันทึก</button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* ── Main tab ── */}
          {activeTab === 'main' && (
            <>
              {myAnnouncements.map((a, idx) => (
                <div key={a.id} {...ui('announce-banner mb-3')}>
                  <span {...ui('announce-icon')}>📢</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', gap: '.4rem', alignItems: 'center', flexWrap: 'wrap', marginBottom: '.15rem' }}>
                      {(!a.target || a.target === 'all') ? (
                        <span style={{ background: '#dbeafe', color: '#1e40af', fontSize: '.65rem', fontWeight: 700, padding: '1px 7px', borderRadius: '999px' }}>ทุกคน</span>
                      ) : (
                        <span style={{ background: '#ede9fe', color: '#7c3aed', fontSize: '.65rem', fontWeight: 700, padding: '1px 7px', borderRadius: '999px' }}>ห้อง {a.target}</span>
                      )}
                      {idx === 0 && <span style={{ background: '#7c3aed', color: 'white', fontSize: '.63rem', fontWeight: 800, padding: '1px 6px', borderRadius: '999px' }}>ล่าสุด</span>}
                    </div>
                    <div {...ui('announce-title')}>{a.title}</div>
                    {a.body && <div style={{ fontSize: '.78rem', color: '#4b5563', marginTop: '.15rem' }}>{a.body}</div>}
                    <div {...ui('announce-date')}>📅 {a.date}</div>
                  </div>
                </div>
              ))}

              {/* Stats */}
              <div {...ui('grid grid-4 mb-6', { gap: '.75rem' })}>
                <div {...ui('stat-card', { background: 'linear-gradient(135deg,#7c3aed,#a855f7)' })}>
                  <span {...ui('stat-icon')}>👶</span>
                  <div {...ui('stat-value')}>{stats.total}</div>
                  <div {...ui('stat-label')}>นักเรียน (ปกติ)</div>
                </div>
                <div {...ui('stat-card', { background: 'linear-gradient(135deg,#10b981,#34d399)' })}>
                  <span {...ui('stat-icon')}>✅</span>
                  <div {...ui('stat-value')}>{stats.attend}</div>
                  <div {...ui('stat-label')}>มาเรียนวันนี้</div>
                </div>
                <div {...ui('stat-card', { background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' })}>
                  <span {...ui('stat-icon')}>🥛</span>
                  <div {...ui('stat-value')}>{stats.hygiene}</div>
                  <div {...ui('stat-label')}>บันทึกกิจวัตรแล้ว</div>
                </div>
                <div {...ui('stat-card', { background: 'linear-gradient(135deg,#3b82f6,#60a5fa)' })}>
                  <span {...ui('stat-icon')}>📋</span>
                  <div {...ui('stat-value')}>{stats.assessed}</div>
                  <div {...ui('stat-label')}>ประเมินแล้ว</div>
                </div>
              </div>

              {/* Monthly attendance slide chart */}
              {monthlyChartData.length > 0 && (() => {
                const cur = monthlyChartData[slideIdx] ?? monthlyChartData[0];
                const avgColor = cur.avgPct === null ? '#64748b'
                  : cur.avgPct >= 80 ? '#065f46' : cur.avgPct >= 60 ? '#92400e' : '#991b1b';
                const avgBg = cur.avgPct === null ? '#f1f5f9'
                  : cur.avgPct >= 80 ? '#d1fae5' : cur.avgPct >= 60 ? '#fef3c7' : '#fee2e2';
                const BAR_W = 11, BAR_GAP = 3, CHART_H = 52, BASE_Y = 58;
                const totalW = cur.bars.length * (BAR_W + BAR_GAP);
                return (
                  <div style={{
                    marginBottom: '.75rem', background: '#fff', borderRadius: '14px',
                    padding: '.85rem 1rem .6rem', boxShadow: '0 1px 4px #0001',
                    userSelect: 'none',
                  }}>
                    {/* Header row */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '.35rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '.5rem' }}>
                        <span style={{ fontSize: '.8rem', fontWeight: 800, color: '#334155' }}>📊 สถิติการมาเรียน</span>
                        <span style={{ fontSize: '.75rem', color: '#7c3aed', fontWeight: 700, background: '#f5f3ff', padding: '.1rem .45rem', borderRadius: '8px' }}>
                          {cur.label}
                        </span>
                      </div>
                      <span style={{ fontWeight: 800, fontSize: '.95rem', background: avgBg, color: avgColor, padding: '.15rem .6rem', borderRadius: '8px' }}>
                        {cur.avgPct !== null ? `${cur.avgPct}%` : '—'}
                      </span>
                    </div>

                    {/* SVG bar chart */}
                    <div style={{ overflowX: 'hidden' }}>
                      <svg
                        viewBox={`0 0 ${Math.max(totalW, 200)} 65`}
                        preserveAspectRatio="none"
                        style={{ width: '100%', height: '68px', display: 'block' }}
                      >
                        {/* Guideline 80% */}
                        <line x1="0" y1={BASE_Y - CHART_H * 0.8} x2={Math.max(totalW, 200)} y2={BASE_Y - CHART_H * 0.8}
                          stroke="#e2e8f0" strokeWidth="0.8" strokeDasharray="3,2" />
                        {/* Bars */}
                        {cur.bars.map((bar, i) => {
                          const x = i * (BAR_W + BAR_GAP);
                          if (bar.pct === null) {
                            return <rect key={bar.dateISO} x={x} y={BASE_Y - 3} width={BAR_W} height={3} rx="2" fill="#e2e8f0" />;
                          }
                          const h = Math.max(Math.round(bar.pct * CHART_H / 100), 2);
                          const fill = bar.pct >= 80 ? '#10b981' : bar.pct >= 60 ? '#f59e0b' : '#ef4444';
                          return (
                            <g key={bar.dateISO}>
                              <rect x={x} y={BASE_Y - h} width={BAR_W} height={h} rx="2" fill={fill} opacity="0.9" />
                            </g>
                          );
                        })}
                        {/* Baseline */}
                        <line x1="0" y1={BASE_Y} x2={Math.max(totalW, 200)} y2={BASE_Y} stroke="#cbd5e1" strokeWidth="0.8" />
                      </svg>
                    </div>

                    {/* Legend + dots */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '.25rem' }}>
                      <div style={{ display: 'flex', gap: '.6rem' }}>
                        {[['#10b981','≥80%'],['#f59e0b','60-79%'],['#ef4444','<60%'],['#e2e8f0','ยังไม่บันทึก']].map(([c, l]) => (
                          <span key={l} style={{ display: 'flex', alignItems: 'center', gap: '.2rem', fontSize: '.65rem', color: '#64748b' }}>
                            <span style={{ width: 8, height: 8, borderRadius: 2, background: c, display: 'inline-block' }} />{l}
                          </span>
                        ))}
                      </div>
                      <div style={{ display: 'flex', gap: '.3rem', alignItems: 'center' }}>
                        {monthlyChartData.map((_, i) => (
                          <button key={i} type="button" onClick={() => setSlideIdx(i)}
                            style={{
                              width: i === slideIdx ? 18 : 7, height: 7, borderRadius: 4, border: 'none',
                              cursor: 'pointer', padding: 0, transition: 'width .3s ease',
                              background: i === slideIdx ? '#7c3aed' : '#cbd5e1',
                            }} />
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Quick actions */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: '.75rem', marginBottom: '1.5rem' }}>
                <button type="button" {...ui('btn', { background: '#d1fae5', color: '#065f46', padding: '.85rem', fontSize: '.9rem', borderRadius: '14px' })}
                  onClick={() => { loadDraft(today); setActiveView('hygiene'); }}>
                  🥛 บันทึกกิจวัตร
                </button>
                <button type="button" {...ui('btn', { background: '#fef3c7', color: '#92400e', padding: '.85rem', fontSize: '.9rem', borderRadius: '14px' })}
                  onClick={() => { loadDraft(today); setActiveView('attendance'); }}>
                  ✅ เช็คชื่อ
                </button>
                <button type="button" {...ui('btn', { background: '#dbeafe', color: '#1e40af', padding: '.85rem', fontSize: '.9rem', borderRadius: '14px' })}
                  onClick={() => {
                    const text = prompt('วางข้อมูล CSV (ชื่อ, ชั้น, อายุ, น้ำหนัก, ส่วนสูง)\nเช่น: เด็กชายดีใจ, K3, 5, 18.5, 110');
                    if (text) {
                      const r = handleImport('students', 'name,level,age,weight,height\n' + text);
                      alert(r.ok ? 'นำเข้าข้อมูลสำเร็จ! ✅' : r.message);
                    }
                  }}>
                  📥 นำเข้าข้อมูล
                </button>
                <button type="button" {...ui('btn btn-primary', { padding: '.85rem', fontSize: '.9rem', borderRadius: '14px' })}
                  onClick={() => setIsAddingLocal(true)}>
                  ➕ เพิ่มนักเรียน
                </button>
              </div>

              {/* Student list */}
              <StudentList myStudents={myStudents} filtered={filtered} search={search} setSearch={setSearch}
                myClass={myClass} today={today} dailyRecords={dailyRecords}
                setSelectedStudent={setSelectedStudent} setEvaluatingStudent={setEvaluatingStudent}
                setEditingStudentLocal={setEditingStudentLocal} handleDelete={handleDelete} />
            </>
          )}

        </Suspense>
        </ErrorBoundary>
      </div>

      {/* ── Student modals ── */}
      <StudentModal
        isOpen={isAddingLocal}
        onClose={() => setIsAddingLocal(false)}
        onSave={handleAddStudentLocal}
      />
      <StudentModal
        key={editingStudentLocal?.id ?? 'edit'}
        isOpen={editingStudentLocal !== null}
        onClose={() => setEditingStudentLocal(null)}
        editingStudent={editingStudentLocal}
        onSave={handleEditStudentLocal}
      />
    </div>
  );
}
