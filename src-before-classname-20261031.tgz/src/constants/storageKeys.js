export const STORAGE_KEYS = {
  students:         'kt_students',
  teachers:         'kt_teachers',
  classes:          'kt_classes',
  schools:          'kt_schools',
  assessmentTopics: 'kt_assessmentTopics',
  announcements:    'kt_announcements',
  academicYears:    'kt_academicYears',
  schoolName:       'kt_schoolName',
  academicYear:     'kt_academicYear',
  dailyRecords:     'kt_dailyRecords',
  authConfig:       'kt_authConfig',
  holidays:         'kt_holidays',
  qaData:           'kt_qaData',
  indicators:       'kt_indicators',
  activities:       'kt_activities',
  schoolTerms:      'kt_schoolTerms',
  activityLogs:     'kt_activityLogs',
  systemLogs:       'kt_systemLogs',       // บันทึกการใช้งานระบบ (login, CRUD, รายงาน)
  pickupRecords:    'kt_pickupRecords',
  mediaRecords:       'kt_mediaRecords',
  mediaBorrowRecords: 'kt_mediaBorrowRecords', // รายการยืม-คืนสื่อการสอน
  cornerRecords:      'kt_cornerRecords',      // การใช้แหล่งเรียนรู้นอกห้องเรียนรายสัปดาห์
  innerCornerRecords: 'kt_innerCornerRecords', // การใช้มุมประสบการณ์ภายในห้องเรียนรายสัปดาห์
  healthCheckRecords:  'kt_healthCheckRecords',  // การตรวจสุขภาพประจำสัปดาห์
  illnessCheckRecords: 'kt_illnessCheckRecords', // คัดกรองอาการป่วยรายห้องเรียนรายเดือน
  toothBrushRecords:   'kt_toothBrushRecords',   // บันทึกการแปรงฟันรายเดือน
  lunchRecords:        'kt_lunchRecords',         // บันทึกการรับประทานอาหารกลางวันรายเดือน
  milkRecords:         'kt_milkRecords',          // บันทึกการดื่มนมรายเดือน
  nutritionRecords:    'kt_nutritionRecords',      // การประเมินภาวะโภชนาการ
  studentReportRecords: 'kt_studentReportRecords', // สมุดรายงานประจำตัวเด็กปฐมวัย (อ.01)
  schoolPhilosophy:     'kt_schoolPhilosophy',     // ปรัชญาการศึกษาปฐมวัย
  schoolVision:         'kt_schoolVision',          // วิสัยทัศน์
  localGovSlogan:       'kt_localGovSlogan',        // คำขวัญขององค์กรปกครองส่วนท้องถิ่น
  schoolSlogan:         'kt_schoolSlogan',           // คำขวัญของสถานศึกษาในสังกัด อปท.
  cornerDefs:           'kt_cornerDefs',             // นิยามมุมแหล่งเรียนรู้นอกห้องเรียน (แก้ไขได้)
  innerCornerDefs:      'kt_innerCornerDefs',        // นิยามมุมประสบการณ์ในห้องเรียน (แก้ไขได้)
  classInnerCornerKeys: 'kt_classInnerCornerKeys',  // กิจกรรมในห้องเรียนที่กำหนดต่อห้อง { [className]: string[] }
  classOuterCornerKeys: 'kt_classOuterCornerKeys',  // กิจกรรมนอกห้องเรียนที่กำหนดต่อห้อง { [className]: string[] }
  aiApiKey:             'kt_aiApiKey',               // Claude API Key สำหรับฟีเจอร์ AI
  imgbbApiKey:          'kt_imgbbApiKey',             // ImgBB API Key สำหรับอัปโหลดรูปภาพนักเรียน
  schoolLogo:           'kt_schoolLogo',              // โลโก้โรงเรียน (base64 dataURL)
  schoolDirectorName:   'kt_schoolDirectorName',      // ชื่อผู้บริหารสถานศึกษา (ค่า default)
  yearDirectors:        'kt_yearDirectors',            // ชื่อผู้บริหารรายปีการศึกษา { "2567": "นาง..." }
  currentTerm:          'kt_currentTerm',             // ภาคเรียนปัจจุบัน ('1' หรือ '2')
  measurementDates:     'kt_measurementDates',        // วันกำหนดวัดน้ำหนัก/ส่วนสูง 4 ครั้ง (อ.01)
  parentCommentDeadlines: 'kt_parentCommentDeadlines', // วันสุดท้ายที่ผู้ปกครองกรอกความคิดเห็น { term1, term2 }
  abilityAssessments:  'kt_abilityAssessments',       // ประเมินความสามารถผู้เรียน หลักสูตรปฐมวัย 2560 { [sid||year||term]: { [code]: score } }
  dailyRoutineRecords:  'kt_dailyRoutineRecords',     // บันทึกกิจกรรมประจำวันระดับชั้นเรียน (เช้า/ออกกำลังกาย/วงกลม/นิทาน/เก็บของ/แต่งตัว)
  specialEvents:        'kt_specialEvents',           // กิจกรรมวันสำคัญ พร้อมรายชื่อผู้เข้าร่วมและตัวบ่งชี้ที่เชื่อมโยง
  lockedTerms:          'kt_lockedTerms',             // ภาคเรียนที่ถูกล็อก { "2567-0": true, "2567-1": true }
  specialHolidays:     'kt_specialHolidays',          // วันหยุดพิเศษ + วันเรียนทดแทน
  menuPermissions:      'kt_menuPermissions',          // { [userId]: { [tabId]: false } } — tab ที่ admin ซ่อนให้ user
  role:                 'kt_role',                    // บทบาทผู้ใช้ (admin/teacher/parent)
  sessionUser:          'kt_sessionUser',             // ข้อมูลผู้ใช้ที่ login อยู่ (name, email, className ฯลฯ)
};

export function clearAllStorage() {
  Object.values(STORAGE_KEYS).forEach((key) => localStorage.removeItem(key));
}
